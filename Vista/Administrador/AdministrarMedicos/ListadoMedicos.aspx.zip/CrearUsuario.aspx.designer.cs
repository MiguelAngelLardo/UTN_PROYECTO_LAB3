﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código. 
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace Vista.Administrador.AdministrarMedicos
{


  public partial class CrearUsuario
  {

    /// <summary>
    /// Control lblLegajoMedico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblLegajoMedico;

    /// <summary>
    /// Control txtLegajoMedico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtLegajoMedico;

    /// <summary>
    /// Control rfvLegajoMedico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvLegajoMedico;

    /// <summary>
    /// Control lblUsuario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblUsuario;

    /// <summary>
    /// Control txtUsuario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtUsuario;

    /// <summary>
    /// Control rfvUsuario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvUsuario;

    /// <summary>
    /// Control revUsuario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RegularExpressionValidator revUsuario;

    /// <summary>
    /// Control lblContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblContraseña;

    /// <summary>
    /// Control txtContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtContraseña;

    /// <summary>
    /// Control rfvContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvContraseña;

    /// <summary>
    /// Control revContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RegularExpressionValidator revContraseña;

    /// <summary>
    /// Control lblRepitaContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblRepitaContraseña;

    /// <summary>
    /// Control txtRepitaContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtRepitaContraseña;

    /// <summary>
    /// Control rfvRepitaContraseña.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvRepitaContraseña;

    /// <summary>
    /// Control cvContraseñas.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CompareValidator cvContraseñas;

    /// <summary>
    /// Control btnGuardarUsuario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Button btnGuardarUsuario;

    /// <summary>
    /// Control lblResultado.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblResultado;
  }
}
