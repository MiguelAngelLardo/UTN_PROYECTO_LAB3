﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código. 
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace Vista.Administrador.AdministrarMedicos
{


  public partial class FormAgregarMedico
  {

    /// <summary>
    /// Control lblLegajo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblLegajo;

    /// <summary>
    /// Control txtLegajo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtLegajo;

    /// <summary>
    /// Control cvLegajo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvLegajo;

    /// <summary>
    /// Control lblNombre.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblNombre;

    /// <summary>
    /// Control txtNombre.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtNombre;

    /// <summary>
    /// Control rfvNombre.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvNombre;

    /// <summary>
    /// Control lblSexo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblSexo;

    /// <summary>
    /// Control ddlSexo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.DropDownList ddlSexo;

    /// <summary>
    /// Control rfvSexo.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvSexo;

    /// <summary>
    /// Control lblPronvica.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblPronvica;

    /// <summary>
    /// Control ddlProvincias.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.DropDownList ddlProvincias;

    /// <summary>
    /// Control rfvProvincia.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvProvincia;

    /// <summary>
    /// Control lblCorreoElectronico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblCorreoElectronico;

    /// <summary>
    /// Control txtCorreoElectronico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtCorreoElectronico;

    /// <summary>
    /// Control cvMail.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvMail;

    /// <summary>
    /// Control lblEspecialidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblEspecialidad;

    /// <summary>
    /// Control ddlEspecialidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.DropDownList ddlEspecialidad;

    /// <summary>
    /// Control rfvEspecialidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvEspecialidad;

    /// <summary>
    /// Control lblFechaNacimiento.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblFechaNacimiento;

    /// <summary>
    /// Control txtFechaNacimiento.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtFechaNacimiento;

    /// <summary>
    /// Control cvEdadMinima.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvEdadMinima;

    /// <summary>
    /// Control lblDNI.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblDNI;

    /// <summary>
    /// Control txtDNI.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtDNI;

    /// <summary>
    /// Control cvDni.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvDni;

    /// <summary>
    /// Control lblApellido.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblApellido;

    /// <summary>
    /// Control txtApellido.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtApellido;

    /// <summary>
    /// Control rfvApellido.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvApellido;

    /// <summary>
    /// Control lblNacionalidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblNacionalidad;

    /// <summary>
    /// Control txtNacionalidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtNacionalidad;

    /// <summary>
    /// Control rfvNacionalidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvNacionalidad;

    /// <summary>
    /// Control lblLocalidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblLocalidad;

    /// <summary>
    /// Control ddlLocalidades.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.DropDownList ddlLocalidades;

    /// <summary>
    /// Control rfvLocalidad.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvLocalidad;

    /// <summary>
    /// Control lblDireccion.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblDireccion;

    /// <summary>
    /// Control txtDireccion.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtDireccion;

    /// <summary>
    /// Control rfvDireccion.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvDireccion;

    /// <summary>
    /// Control lblTelefono.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblTelefono;

    /// <summary>
    /// Control txtTelefono.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.TextBox txtTelefono;

    /// <summary>
    /// Control cvTel.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvTel;

    /// <summary>
    /// Control lblTurnoHorario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblTurnoHorario;

    /// <summary>
    /// Control ddlTurnoHorario.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.DropDownList ddlTurnoHorario;

    /// <summary>
    /// Control rfvHorarios.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.RequiredFieldValidator rfvHorarios;

    /// <summary>
    /// Control lblDias.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblDias;

    /// <summary>
    /// Control cblDias.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CheckBoxList cblDias;

    /// <summary>
    /// Control cvDias.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.CustomValidator cvDias;

    /// <summary>
    /// Control lblMensajeExito.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblMensajeExito;

    /// <summary>
    /// Control lblMensajeError.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Label lblMensajeError;

    /// <summary>
    /// Control btnGuardarMedico.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.Button btnGuardarMedico;

    /// <summary>
    /// Control hlVolver.
    /// </summary>
    /// <remarks>
    /// Campo generado automáticamente.
    /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
    /// </remarks>
    protected global::System.Web.UI.WebControls.HyperLink hlVolver;
  }
}
