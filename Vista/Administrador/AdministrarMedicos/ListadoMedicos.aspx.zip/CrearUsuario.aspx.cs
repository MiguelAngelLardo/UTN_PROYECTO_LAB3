﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Vista.Administrador.AdministrarMedicos
{
  public partial class CrearUsuario : System.Web.UI.Page
  {
    NegocioMedico negocioMedico = new NegocioMedico();


    protected void Page_Load(object sender, EventArgs e)
    {
      string legajo = Request.QueryString["legajo"];
      if (!string.IsNullOrEmpty(legajo))
      {
        txtLegajoMedico.Text = legajo;
        txtLegajoMedico.ReadOnly = true;
      }
    }

    protected void btnGuardarUsuario_Click(object sender, EventArgs e)
    {
      if (txtContraseña.Text != txtRepitaContraseña.Text)
      {
        lblResultado.Text = "Las contraseñas no coinciden. Por favor, intente nuevamente.";
        return;
      }
      string legajo = Request.QueryString["legajo"];
      string usuario = txtUsuario.Text.Trim();
      string password = txtContraseña.Text.Trim();
      // Lógica para guardar el usuario y la contraseña en la base de datos
      bool creado = negocioMedico.CrearUsuarioMedico(legajo, usuario, password);

      if (creado)
      {
        lblResultado.ForeColor = System.Drawing.Color.Green;
        lblResultado.Text = "Usuario creado exitosamente.";
        txtUsuario.Text = "";
        txtContraseña.Text = "";
        txtRepitaContraseña.Text = "";
        return;
      }
      else
      {
        lblResultado.ForeColor = System.Drawing.Color.Red;
        lblResultado.Text = "Error al crear el usuario. Verifique los datos e intente nuevamente.";
        return;
      }
    }
  }
}