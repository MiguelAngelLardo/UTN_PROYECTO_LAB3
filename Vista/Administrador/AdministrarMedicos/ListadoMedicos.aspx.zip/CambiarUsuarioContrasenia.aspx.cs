﻿using Negocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Vista.Administrador.AdministrarMedicos
{
    public partial class CambiarUsuarioContrasenia : System.Web.UI.Page
    {
        NegocioMedico negocioMedico = new NegocioMedico();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                obtenerLegajoMedico();
                obtenerNombreUsuario();
                divCambioUsuario.Visible = true;
                divCambioContraseña.Visible = false;
            }
        }
        protected void obtenerLegajoMedico()
        {
            string legajo = Request.QueryString["legajo"];
            if (!string.IsNullOrEmpty(legajo))
            {
                txtLegajoMedicoCambio.Text = legajo;
                txtLegajoMedicoCambio.ReadOnly = true;
            }
        }
        protected void obtenerNombreUsuario()
        {             
            string legajo = Request.QueryString["legajo"];
            if (!string.IsNullOrEmpty(legajo))
            {
                string nombreUsuario = negocioMedico.ObtenerNombreUsuarioPorLegajo(legajo);
                txtUsuarioCambio.Text = nombreUsuario;
            }
        }
        protected void radioOpcionCambio_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Alternar visibilidad según opción seleccionada
            string opcion = radioOpcionCambio.SelectedValue;

            divCambioUsuario.Visible = opcion == "Usuario";
            divCambioContraseña.Visible = opcion == "Contraseña";
            lblResultadoCambio.Text = "";
        }

        protected void btnGuardarCambio_Click(object sender, EventArgs e)
        {
            string opcion = radioOpcionCambio.SelectedValue;
            string legajo = Request.QueryString["legajo"];

            if (opcion == "Usuario")
            {
                string nuevoUsuario = txtUsuarioCambio.Text;
                bool cambiado = negocioMedico.CambiarUsuario(legajo, nuevoUsuario);
                if (cambiado)
                {
                    txtUsuarioCambio.Text = "";
                    lblResultadoCambio.ForeColor = System.Drawing.Color.Green;
                    lblResultadoCambio.Text = "Usuario cambiado a: " + nuevoUsuario;
                }
                else
                {
                    txtUsuarioCambio.Text = "";
                    lblResultadoCambio.ForeColor = System.Drawing.Color.Red;
                    lblResultadoCambio.Text = "Error al cambiar el usuario. Verifique los datos e intente nuevamente.";
                }
            }
            else if (opcion == "Contraseña")
            {
                string nuevaContraseña = txtContraseñaCambio.Text;
                bool cambiado = negocioMedico.CambiarContrasenia(legajo, nuevaContraseña);
                if(cambiado)
                {
                    txtContraseñaCambio.Text = "";
                    txtRepitaContraseñaCambio.Text = "";
                    lblResultadoCambio.ForeColor = System.Drawing.Color.Green;
                    lblResultadoCambio.Text = "Contraseña cambiada exitosamente.";
                }
                else
                {
                    txtContraseñaCambio.Text = "";
                    txtRepitaContraseñaCambio.Text = "";
                    lblResultadoCambio.ForeColor = System.Drawing.Color.Red;
                    lblResultadoCambio.Text = "Error al cambiar la contraseña. Verifique los datos e intente nuevamente.";
                }
            }
        }

        protected void btnEliminarUsuario_Click(object sender, EventArgs e)
        {
            string legajo = Request.QueryString["legajo"];
            btnGuardarCambio.Visible = false;
            bool eliminado = negocioMedico.EliminarUsuario(legajo);
            if (eliminado)
            {
                txtUsuarioCambio.Text = "";
                txtContraseñaCambio.Text = "";
                txtRepitaContraseñaCambio.Text = "";
                lblResultadoCambio.ForeColor = System.Drawing.Color.Green;
                lblResultadoCambio.Text = "Usuario eliminado exitosamente.";
            }
            else
            {
                lblResultadoCambio.ForeColor = System.Drawing.Color.Red;
                lblResultadoCambio.Text = "Error al eliminar el usuario. Verifique los datos e intente nuevamente.";
            }
        }
    }
}